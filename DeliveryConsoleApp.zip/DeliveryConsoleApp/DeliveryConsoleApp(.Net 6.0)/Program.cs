﻿using DeliveryConsoleApp_.Net_6._0_.Assistment;
using Microsoft.Extensions.Configuration;
using System.Globalization;

class Program
{
    static void Main(string[] args)
    {
        string baseURL = Directory.GetCurrentDirectory() + "\\resources\\";
        var configFilePath = Path.Combine(baseURL, "appsettings.json");

        var configurationBuilder = new ConfigurationBuilder()
            .SetBasePath(baseURL);

        if (File.Exists(configFilePath))
        {
            configurationBuilder.AddJsonFile("appsettings.json");
        }
        else
        {
            Console.WriteLine("Внимание: файл appsettings.json не найден. Использование значений по умолчанию.");
        }

        var configuration = configurationBuilder.Build();
        string inputFilePath = configuration["FilePaths:InputFilePath"] ?? "defaultInputPath.txt";
        string outputFilePath = configuration["FilePaths:OutputFilePath"] ?? "defaultOutputPath.txt";
        string logFilePath = configuration["FilePaths:LogFilePath"] ?? "defaultLogPath.txt";
        string district = configuration["Filters:District"] ?? "defaultDistrict";

        DateTime firstDeliveryTime;
        if (!DateTime.TryParseExact(configuration["Filters:FirstDeliveryTime"], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out firstDeliveryTime))
        {
            firstDeliveryTime = DateTime.Now;
        }

        var logger = new Logger(logFilePath);

        try
        {
            logger.Log("Загрузка заказов...");
            var orders = OrderOperation.Load(inputFilePath);

            logger.Log("Фильтрация заказов...");
            var filteredOrders = OrderOperation.Filter(orders, district, firstDeliveryTime);

            logger.Log("Сохранение отфильтрованных заказов...");
            OrderOperation.Save(filteredOrders, outputFilePath);

            logger.Log("Программа выполнена успешно.");
        }
        catch (Exception ex)
        {
            logger.Log($"Произошла ошибка: {ex.Message}");
        }
    }
}