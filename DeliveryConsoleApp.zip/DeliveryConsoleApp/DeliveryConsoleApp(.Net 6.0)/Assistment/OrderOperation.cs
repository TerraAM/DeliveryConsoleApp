﻿using DeliveryConsoleApp_.Net_6._0_.Entity;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliveryConsoleApp_.Net_6._0_.Assistment
{
    public static class OrderOperation
    {
        public static List<Order> Load(string filePath)
        {
            var orders = new List<Order>();

            foreach (var line in File.ReadAllLines(filePath))
            {
                var fields = line.Split(';');
                if (fields.Length != 4)
                    continue;
                try
                {
                    var order = new Order
                    {
                        Id = int.Parse(fields[0]),
                        Weight = double.Parse(fields[1]),
                        CityDistrict = fields[2],
                        DeliveryDateTime = DateTime.ParseExact(fields[3], "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
                    };
                    orders.Add(order);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка строки: {line} - {ex.Message}");
                }
            }
            return orders;
        }
        public static void Save(List<Order> orders, string filePath)
        {
            var lines = orders.Select(o => $"{o.Id};{o.Weight};{o.CityDistrict};{o.DeliveryDateTime:yyyy-MM-dd HH:mm:ss}");
            File.WriteAllLines(filePath, lines, Encoding.UTF8);
        }

        public static List<Order> Filter(List<Order> orders, string targetDistrict, DateTime firstDeliveryTime)
        {
            return orders
                .Where(order => order.CityDistrict == targetDistrict &&
                                order.DeliveryDateTime >= firstDeliveryTime &&
                                order.DeliveryDateTime <= firstDeliveryTime.AddMinutes(30))
                .ToList();
        }

    }
}
