﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliveryConsoleApp_.Net_6._0_.Entity
{
    public class Order
    {
        public int Id { get; set; }
        public double Weight { get; set; }
        public string CityDistrict { get; set; } = string.Empty;
        public DateTime DeliveryDateTime { get; set; }
    }
}
