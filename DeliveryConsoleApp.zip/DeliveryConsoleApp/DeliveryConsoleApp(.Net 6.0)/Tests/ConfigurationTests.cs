﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace DeliveryConsoleApp_.Net_6._0_.Tests
{
    public class ConfigurationTests
    {
        [Fact]
        public void MissingConfigFile_ShouldUseDefaultValues()
        {
            // Arrange
            var baseURL = Directory.GetCurrentDirectory() + "\\resources\\";
            string configFilePath = Path.Combine(baseURL, "appsettings.json");

            // Убедимся, что файла конфигурации нет
            if (File.Exists(configFilePath))
                File.Delete(configFilePath);

            var configurationBuilder = new ConfigurationBuilder().SetBasePath(baseURL);
            var configuration = configurationBuilder.Build();

            // Act
            string inputFilePath = configuration["FilePaths:InputFilePath"] ?? "defaultInputPath.txt";
            string outputFilePath = configuration["FilePaths:OutputFilePath"] ?? "defaultOutputPath.txt";
            string logFilePath = configuration["FilePaths:LogFilePath"] ?? "defaultLogPath.txt";
            string district = configuration["Filters:District"] ?? "defaultDistrict";

            // Assert
            Assert.Equal("defaultInputPath.txt", inputFilePath);
            Assert.Equal("defaultOutputPath.txt", outputFilePath);
            Assert.Equal("defaultLogPath.txt", logFilePath);
            Assert.Equal("defaultDistrict", district);
        }
    }
}
