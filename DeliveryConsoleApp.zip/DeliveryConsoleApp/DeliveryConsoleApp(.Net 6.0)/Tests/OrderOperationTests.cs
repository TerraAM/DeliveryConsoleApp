﻿using DeliveryConsoleApp_.Net_6._0_.Assistment;
using DeliveryConsoleApp_.Net_6._0_.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace DeliveryConsoleApp_.Net_6._0_.Tests
{
    public class OrderOperationTests
    {
        [Fact]
        public void Load_ValidFile_ShouldReturnListOfOrders()
        {
            // Arrange
            string testFilePath = "test_orders.txt";
            File.WriteAllLines(testFilePath, new[]
            {
            "1;2.5;DistrictA;2023-01-01 10:00:00",
            "2;3.0;DistrictB;2023-01-01 11:00:00"
        });

            // Act
            var orders = OrderOperation.Load(testFilePath);

            // Assert
            Assert.Equal(2, orders.Count);
            Assert.Equal(1, orders[0].Id);
            Assert.Equal(2.5, orders[0].Weight);
            Assert.Equal("DistrictA", orders[0].CityDistrict);
            Assert.Equal(new DateTime(2023, 1, 1, 10, 0, 0), orders[0].DeliveryDateTime);

            // Cleanup
            File.Delete(testFilePath);
        }

        [Fact]
        public void Load_InvalidLineFormat_ShouldSkipInvalidLines()
        {
            // Arrange
            string testFilePath = "test_invalid_orders.txt";
            File.WriteAllLines(testFilePath, new[]
            {
            "1;2.5;DistrictA;2023-01-01 10:00:00",
            "invalid_line",
            "3;4.0;DistrictC;2023-01-01 12:00:00"
        });

            // Act
            var orders = OrderOperation.Load(testFilePath);

            // Assert
            Assert.Equal(2, orders.Count);
            Assert.Equal(1, orders[0].Id);
            Assert.Equal(3, orders[1].Id);

            // Cleanup
            File.Delete(testFilePath);
        }

        [Fact]
        public void Filter_ByDistrictAndTime_ShouldReturnFilteredOrders()
        {
            // Arrange
            var orders = new List<Order>
        {
            new Order { Id = 1, CityDistrict = "DistrictA", DeliveryDateTime = new DateTime(2023, 1, 1, 10, 0, 0) },
            new Order { Id = 2, CityDistrict = "DistrictA", DeliveryDateTime = new DateTime(2023, 1, 1, 10, 10, 0) },
            new Order { Id = 3, CityDistrict = "DistrictB", DeliveryDateTime = new DateTime(2023, 1, 1, 10, 0, 0) }
        };
            string targetDistrict = "DistrictA";
            DateTime firstDeliveryTime = new DateTime(2023, 1, 1, 10, 0, 0);

            // Act
            var filteredOrders = OrderOperation.Filter(orders, targetDistrict, firstDeliveryTime);

            // Assert
            Assert.Equal(2, filteredOrders.Count);
            Assert.All(filteredOrders, order => Assert.Equal("DistrictA", order.CityDistrict));
            Assert.All(filteredOrders, order => Assert.True(order.DeliveryDateTime >= firstDeliveryTime &&
                                                         order.DeliveryDateTime <= firstDeliveryTime.AddMinutes(30)));
        }
    }
}
