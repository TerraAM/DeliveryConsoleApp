﻿using DeliveryConsoleApp_.Net_6._0_.Assistment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace DeliveryConsoleApp_.Net_6._0_.Tests
{
    public class LoggerTests
    {
        [Fact]
        public void Log_Message_ShouldWriteToFile()
        {
            // Arrange
            string testLogFilePath = "test_log.txt";
            var logger = new Logger(testLogFilePath);

            // Act
            logger.Log("Test log message");

            // Assert
            string logContent = File.ReadAllText(testLogFilePath);
            Assert.Contains("Test log message", logContent);

            // Cleanup
            File.Delete(testLogFilePath);
        }
    }
}
